package com.example.onlineopd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class otpScreen2 extends AppCompatActivity {
    String verificationCodeSendBySystem;
    String TAG = "mainActivity";
     Button resendBtn;
     TextView counterTv;
     Button verificationBtn;
    TextView verifyTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpscreen2);

        resendBtn =  findViewById(R.id.resendBtn);
        counterTv =  findViewById(R.id.counterTv);
        verificationBtn = findViewById(R.id.verificationBtn);
         verifyTv = findViewById(R.id.verifyTv);
         Intent intent = getIntent();
        String a = intent.getStringExtra("MIHIR");

        assert a != null;
        Log.e(TAG, a);
        verifyTv.setText(a);



        String phone = verifyTv.getText().toString();
        new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {
                counterTv.setText("Seconds remaining: " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                resendBtn.setEnabled(true);
            }
        }.start();

//        verificationBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent1 = new Intent(otpScreen2.this , Registration.class);
//                         startActivity(intent1);
//
//
//            }
//        });
        //
        sendVerificationCodeToUser(a);

        resendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });

    }

    private void sendVerificationCodeToUser(String number)
    {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                "+91" +  number,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallBacks

        );
    }
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallBacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
            String code = phoneAuthCredential.getSmsCode();
            if(code!=null)
            {
                verifyCode(code);
            }
        }
        @Override
        public void onVerificationFailed(@NonNull FirebaseException e) {
            Toast.makeText(otpScreen2.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verificationCodeSendBySystem = s;

        }
    };
//
    private void verifyCode(String CodeByUser) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationCodeSendBySystem,CodeByUser);
        signInUserCredentials(credential);
    }
//
    private void signInUserCredentials(PhoneAuthCredential credential) {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();


        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(otpScreen2.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Intent intent = new Intent(getApplicationContext(), Registration.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        } else {
                            Toast.makeText(otpScreen2.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }
                });

    }


}


